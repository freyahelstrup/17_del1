package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class PlayGameTest {

	@Test
	public void winwithdoublehitafter40points() {
		fail("not yet implemented");
	}

}
